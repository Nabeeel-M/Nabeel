import jsPDF from "jspdf"
import autoTable from "jspdf-autotable"
import type { Technician } from "./types"

export function generatePDF(
  technicians: Technician[],
  miscExpenses: { label: string; amount: number }[],
  totalRemaining: number,
  finalRemaining: number,
) {
  const doc = new jsPDF()

  // Add title
  doc.setFontSize(20)
  doc.setTextColor(20, 184, 166) // Teal color
  doc.text("Expense Tracker Report", 14, 20)

  // Add date
  doc.setFontSize(10)
  doc.setTextColor(100, 100, 100)
  doc.text(`Generated: ${new Date().toLocaleDateString()}`, 14, 28)

  // Prepare technician data
  const technicianData = technicians.map((tech) => [
    tech.name || "N/A",
    tech.totalReceived.toLocaleString(),
    tech.totalExpense.toLocaleString(),
    tech.remaining.toLocaleString(),
    tech.remarks || "",
  ])

  // Add technician table
  autoTable(doc, {
    startY: 35,
    head: [["Technician", "Total Received", "Total Expense", "Remaining", "Remarks"]],
    body: technicianData,
    theme: "grid",
    headStyles: {
      fillColor: [20, 184, 166],
      textColor: [255, 255, 255],
      fontStyle: "bold",
    },
    styles: {
      fontSize: 9,
      cellPadding: 3,
    },
    columnStyles: {
      1: { halign: "right" },
      2: { halign: "right" },
      3: { halign: "right", fontStyle: "bold", textColor: [20, 184, 166] },
    },
  })

  // Get the final Y position after the table
  const finalY = (doc as any).lastAutoTable.finalY + 10

  // Add summary section
  doc.setFontSize(12)
  doc.setTextColor(20, 184, 166)
  doc.text("Summary", 14, finalY)

  // Add total
  doc.setFontSize(10)
  doc.setTextColor(0, 0, 0)
  doc.text(`Total Remaining:`, 14, finalY + 8)
  doc.text(totalRemaining.toLocaleString(), 180, finalY + 8, { align: "right" })

  // Add misc expenses
  let currentY = finalY + 15
  miscExpenses.forEach((expense) => {
    doc.text(`${expense.label}:`, 14, currentY)
    doc.text(expense.amount.toLocaleString(), 180, currentY, { align: "right" })
    currentY += 6
  })

  // Add final remaining
  doc.setFontSize(12)
  doc.setFont(undefined, "bold")
  doc.setTextColor(20, 184, 166)
  doc.text("Final Remaining:", 14, currentY + 5)
  doc.text(finalRemaining.toLocaleString(), 180, currentY + 5, { align: "right" })

  // Save the PDF
  doc.save(`expense-tracker-${new Date().toISOString().split("T")[0]}.pdf`)
}
