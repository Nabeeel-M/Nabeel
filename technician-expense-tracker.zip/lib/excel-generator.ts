import * as XLSX from "xlsx"
import type { Technician } from "./types"

export function generateExcel(
  technicians: Technician[],
  miscExpenses: { label: string; amount: number }[],
  totalRemaining: number,
  finalRemaining: number,
) {
  // Prepare technician data
  const technicianData = technicians.map((tech) => ({
    Technician: tech.name || "N/A",
    "Total Received": tech.totalReceived,
    "Total Expense": tech.totalExpense,
    Remaining: tech.remaining,
    Remarks: tech.remarks || "",
  }))

  // Add empty row
  technicianData.push({
    Technician: "",
    "Total Received": "",
    "Total Expense": "",
    Remaining: "",
    Remarks: "",
  } as any)

  // Add total row
  technicianData.push({
    Technician: "",
    "Total Received": "",
    "Total Expense": "Total",
    Remaining: totalRemaining,
    Remarks: "",
  } as any)

  // Add misc expenses
  miscExpenses.forEach((expense) => {
    technicianData.push({
      Technician: "",
      "Total Received": "",
      "Total Expense": expense.label,
      Remaining: expense.amount,
      Remarks: "",
    } as any)
  })

  // Add empty row
  technicianData.push({
    Technician: "",
    "Total Received": "",
    "Total Expense": "",
    Remaining: "",
    Remarks: "",
  } as any)

  // Add final remaining
  technicianData.push({
    Technician: "",
    "Total Received": "",
    "Total Expense": "Final Remaining",
    Remaining: finalRemaining,
    Remarks: "",
  } as any)

  // Create worksheet
  const ws = XLSX.utils.json_to_sheet(technicianData)

  // Create workbook
  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, ws, "Expense Tracker")

  // Save file
  XLSX.writeFile(wb, `expense-tracker-${new Date().toISOString().split("T")[0]}.xlsx`)
}
