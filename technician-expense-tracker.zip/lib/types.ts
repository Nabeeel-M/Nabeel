export interface Technician {
  id: string
  name: string
  totalReceived: number
  totalExpense: number
  remaining: number
  status: "active" | "inactive"
  createdAt: Date
  remarks?: string // Added remarks field for inline notes
}

export interface Transaction {
  id: string
  technicianId: string
  technicianName: string
  type: "received" | "expense"
  amount: number
  category: string
  description: string
  date: Date
  createdAt: Date
}

export type TransactionCategory =
  | "Salary"
  | "Advance"
  | "Bonus"
  | "Tools"
  | "Transport"
  | "Food"
  | "Materials"
  | "Other"
