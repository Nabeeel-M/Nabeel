"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { UserPlus, Receipt, TrendingUp } from "lucide-react"
import { AddTechnicianDialog } from "./add-technician-dialog"
import { AddTransactionDialog } from "./add-transaction-dialog"
import type { Technician, Transaction } from "@/lib/types"

interface QuickActionsProps {
  technicians: Technician[]
  onAddTechnician: (name: string) => void
  onAddTransaction: (transaction: Omit<Transaction, "id" | "createdAt">) => void
}

export function QuickActions({ technicians, onAddTechnician, onAddTransaction }: QuickActionsProps) {
  const [addTechDialogOpen, setAddTechDialogOpen] = useState(false)
  const [addTransactionDialogOpen, setAddTransactionDialogOpen] = useState(false)
  const [transactionType, setTransactionType] = useState<"received" | "expense">("received")

  const handleQuickTransaction = (type: "received" | "expense") => {
    setTransactionType(type)
    setAddTransactionDialogOpen(true)
  }

  const actions = [
    {
      title: "Add Technician",
      description: "Register new team member",
      icon: UserPlus,
      color: "text-primary",
      bgColor: "bg-primary/10",
      onClick: () => setAddTechDialogOpen(true),
    },
    {
      title: "Record Payment",
      description: "Log received amount",
      icon: TrendingUp,
      color: "text-chart-2",
      bgColor: "bg-chart-2/10",
      onClick: () => handleQuickTransaction("received"),
    },
    {
      title: "Add Expense",
      description: "Track spending",
      icon: Receipt,
      color: "text-destructive",
      bgColor: "bg-destructive/10",
      onClick: () => handleQuickTransaction("expense"),
    },
  ]

  return (
    <>
      <Card className="p-6">
        <h2 className="mb-4 text-lg font-semibold">Quick Actions</h2>
        <div className="grid gap-4 md:grid-cols-3">
          {actions.map((action) => {
            const Icon = action.icon
            return (
              <Button
                key={action.title}
                variant="outline"
                className="h-auto flex-col items-start gap-2 p-4 text-left bg-transparent"
                onClick={action.onClick}
              >
                <div className={`rounded-lg p-2 ${action.bgColor}`}>
                  <Icon className={`h-5 w-5 ${action.color}`} />
                </div>
                <div>
                  <div className="font-semibold">{action.title}</div>
                  <div className="text-xs text-muted-foreground">{action.description}</div>
                </div>
              </Button>
            )
          })}
        </div>
      </Card>

      <AddTechnicianDialog open={addTechDialogOpen} onOpenChange={setAddTechDialogOpen} onAdd={onAddTechnician} />

      <AddTransactionDialog
        open={addTransactionDialogOpen}
        onOpenChange={setAddTransactionDialogOpen}
        technicians={technicians}
        onAdd={onAddTransaction}
        defaultType={transactionType}
      />
    </>
  )
}
