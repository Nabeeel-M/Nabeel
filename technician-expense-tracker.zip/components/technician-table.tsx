"use client"

import { useState } from "react"
import type { Technician } from "@/lib/types"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card } from "@/components/ui/card"
import { Edit, Trash2, Plus } from "lucide-react"
import { AddTechnicianDialog } from "./add-technician-dialog"
import { EditTechnicianDialog } from "./edit-technician-dialog"

interface TechnicianTableProps {
  technicians: Technician[]
  onAdd: (name: string) => void
  onEdit: (id: string, name: string, status: "active" | "inactive") => void
  onDelete: (id: string) => void
}

export function TechnicianTable({ technicians, onAdd, onEdit, onDelete }: TechnicianTableProps) {
  const [addDialogOpen, setAddDialogOpen] = useState(false)
  const [editDialogOpen, setEditDialogOpen] = useState(false)
  const [selectedTechnician, setSelectedTechnician] = useState<Technician | null>(null)

  const handleEdit = (technician: Technician) => {
    setSelectedTechnician(technician)
    setEditDialogOpen(true)
  }

  return (
    <Card className="p-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Technicians</h2>
          <p className="text-sm text-muted-foreground">Manage your technician accounts</p>
        </div>
        <Button onClick={() => setAddDialogOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Add Technician
        </Button>
      </div>

      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead className="text-right">Total Received</TableHead>
              <TableHead className="text-right">Total Expense</TableHead>
              <TableHead className="text-right">Remaining</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {technicians.map((technician) => (
              <TableRow key={technician.id}>
                <TableCell className="font-medium">{technician.name}</TableCell>
                <TableCell className="text-right font-mono text-primary">
                  {technician.totalReceived.toLocaleString()}
                </TableCell>
                <TableCell className="text-right font-mono text-destructive">
                  {technician.totalExpense.toLocaleString()}
                </TableCell>
                <TableCell className="text-right font-mono font-semibold">
                  {technician.remaining.toLocaleString()}
                </TableCell>
                <TableCell>
                  <Badge variant={technician.status === "active" ? "default" : "secondary"}>{technician.status}</Badge>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Button variant="ghost" size="icon" onClick={() => handleEdit(technician)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => onDelete(technician.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <AddTechnicianDialog open={addDialogOpen} onOpenChange={setAddDialogOpen} onAdd={onAdd} />

      {selectedTechnician && (
        <EditTechnicianDialog
          open={editDialogOpen}
          onOpenChange={setEditDialogOpen}
          technician={selectedTechnician}
          onEdit={onEdit}
        />
      )}
    </Card>
  )
}
