"use client"
import type { Technician } from "@/lib/types"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Trash2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface SpreadsheetTableProps {
  technicians: Technician[]
  setTechnicians: (technicians: Technician[]) => void
  miscExpenses: { label: string; amount: number }[]
  setMiscExpenses: (expenses: { label: string; amount: number }[]) => void
  totalRemaining: number
  finalRemaining: number
}

export function SpreadsheetTable({
  technicians,
  setTechnicians,
  miscExpenses,
  setMiscExpenses,
  totalRemaining,
  finalRemaining,
}: SpreadsheetTableProps) {
  const { toast } = useToast()

  const handleCellChange = (id: string, field: keyof Technician, value: string | number) => {
    setTechnicians(
      technicians.map((tech) => {
        if (tech.id === id) {
          const updated = { ...tech, [field]: value }
          if (field === "totalReceived" || field === "totalExpense") {
            updated.remaining = Number(updated.totalReceived) - Number(updated.totalExpense)
          }
          return updated
        }
        return tech
      }),
    )
  }

  const handleDeleteRow = (id: string) => {
    setTechnicians(technicians.filter((tech) => tech.id !== id))
    toast({
      title: "Row deleted",
      description: "Technician row has been removed.",
    })
  }

  const handleMiscExpenseChange = (index: number, field: "label" | "amount", value: string | number) => {
    const updated = [...miscExpenses]
    updated[index] = { ...updated[index], [field]: value }
    setMiscExpenses(updated)
  }

  return (
    <div className="rounded-2xl border-2 border-teal-200 bg-white/90 backdrop-blur-sm shadow-2xl overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="bg-gradient-to-r from-teal-600 via-emerald-600 to-teal-600 text-white">
              <th className="border-r border-teal-500 px-4 sm:px-6 py-4 text-left text-xs sm:text-sm font-bold uppercase tracking-wide">
                Technician
              </th>
              <th className="border-r border-teal-500 px-4 sm:px-6 py-4 text-left text-xs sm:text-sm font-bold uppercase tracking-wide">
                Total Received
              </th>
              <th className="border-r border-teal-500 px-4 sm:px-6 py-4 text-left text-xs sm:text-sm font-bold uppercase tracking-wide">
                Total Expense
              </th>
              <th className="border-r border-teal-500 px-4 sm:px-6 py-4 text-left text-xs sm:text-sm font-bold uppercase tracking-wide">
                Remaining
              </th>
              <th className="border-r border-teal-500 px-4 sm:px-6 py-4 text-left text-xs sm:text-sm font-bold uppercase tracking-wide">
                Remarks
              </th>
              <th className="w-12 sm:w-16 px-2 py-4"></th>
            </tr>
          </thead>
          <tbody>
            {technicians.map((tech, index) => (
              <tr
                key={tech.id}
                className={`transition-colors hover:bg-teal-50 ${index % 2 === 0 ? "bg-white" : "bg-slate-50/50"}`}
              >
                <td className="border-r border-slate-200 px-2 sm:px-3 py-2">
                  <Input
                    value={tech.name}
                    onChange={(e) => handleCellChange(tech.id, "name", e.target.value)}
                    className="h-10 sm:h-11 border-0 bg-transparent font-medium text-sm sm:text-base focus-visible:ring-2 focus-visible:ring-teal-500"
                    placeholder="Enter name"
                  />
                </td>
                <td className="border-r border-slate-200 px-2 sm:px-3 py-2">
                  <Input
                    type="number"
                    value={tech.totalReceived || ""}
                    onChange={(e) => handleCellChange(tech.id, "totalReceived", Number(e.target.value) || 0)}
                    className="h-10 sm:h-11 border-0 bg-transparent text-right font-medium text-sm sm:text-base focus-visible:ring-2 focus-visible:ring-teal-500"
                    placeholder="0"
                  />
                </td>
                <td className="border-r border-slate-200 px-2 sm:px-3 py-2">
                  <Input
                    type="number"
                    value={tech.totalExpense || ""}
                    onChange={(e) => handleCellChange(tech.id, "totalExpense", Number(e.target.value) || 0)}
                    className="h-10 sm:h-11 border-0 bg-transparent text-right font-medium text-sm sm:text-base focus-visible:ring-2 focus-visible:ring-teal-500"
                    placeholder="0"
                  />
                </td>
                <td className="border-r border-slate-200 px-2 sm:px-3 py-2">
                  <div className="flex h-10 sm:h-11 items-center justify-end px-3 text-base sm:text-lg font-bold text-teal-700">
                    {tech.remaining.toLocaleString()}
                  </div>
                </td>
                <td className="border-r border-slate-200 px-2 sm:px-3 py-2">
                  <Input
                    value={(tech as any).remarks || ""}
                    onChange={(e) => handleCellChange(tech.id, "remarks" as any, e.target.value)}
                    className="h-10 sm:h-11 border-0 bg-transparent text-sm sm:text-base focus-visible:ring-2 focus-visible:ring-teal-500"
                    placeholder="Add remarks"
                  />
                </td>
                <td className="px-2 py-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDeleteRow(tech.id)}
                    className="h-8 w-8 sm:h-9 sm:w-9 text-red-600 hover:bg-red-50 hover:text-red-700"
                  >
                    <Trash2 className="h-3 w-3 sm:h-4 sm:w-4" />
                  </Button>
                </td>
              </tr>
            ))}

            <tr>
              <td className="border-t-2 border-teal-300 px-4 py-3" colSpan={6}></td>
            </tr>

            <tr className="bg-gradient-to-r from-teal-50 to-emerald-50">
              <td className="border-r border-teal-200 px-4 py-3" colSpan={2}></td>
              <td className="border-r border-teal-200 px-4 sm:px-6 py-4 text-sm sm:text-base font-bold uppercase tracking-wide text-teal-800">
                Total
              </td>
              <td className="border-r border-teal-200 px-4 sm:px-6 py-4 text-right text-lg sm:text-xl font-bold text-teal-700">
                {totalRemaining.toLocaleString()}
              </td>
              <td className="px-4 py-3" colSpan={2}></td>
            </tr>

            {miscExpenses.map((expense, index) => (
              <tr key={index} className="hover:bg-teal-50/50 transition-colors">
                <td className="border-r border-slate-200 px-4 py-2" colSpan={2}></td>
                <td className="border-r border-slate-200 px-2 sm:px-3 py-2">
                  <Input
                    value={expense.label}
                    onChange={(e) => handleMiscExpenseChange(index, "label", e.target.value)}
                    className="h-10 sm:h-11 border-0 bg-transparent font-medium text-sm sm:text-base focus-visible:ring-2 focus-visible:ring-teal-500"
                    placeholder="Label"
                  />
                </td>
                <td className="border-r border-slate-200 px-2 sm:px-3 py-2">
                  <Input
                    type="number"
                    value={expense.amount}
                    onChange={(e) => handleMiscExpenseChange(index, "amount", Number(e.target.value) || 0)}
                    className="h-10 sm:h-11 border-0 bg-transparent text-right font-medium text-sm sm:text-base focus-visible:ring-2 focus-visible:ring-teal-500"
                    placeholder="0"
                  />
                </td>
                <td className="px-4 py-2" colSpan={2}></td>
              </tr>
            ))}

            <tr>
              <td className="border-t-2 border-teal-300 px-4 py-3" colSpan={6}></td>
            </tr>

            <tr className="bg-gradient-to-r from-teal-100 via-emerald-100 to-teal-100">
              <td className="border-r border-teal-200 px-4 py-4" colSpan={2}></td>
              <td className="border-r border-teal-200 px-4 sm:px-6 py-5 text-base sm:text-lg font-bold uppercase tracking-wide text-teal-900">
                Final Remaining
              </td>
              <td className="border-r border-teal-200 px-4 sm:px-6 py-5 text-right text-xl sm:text-2xl font-bold text-teal-700">
                {finalRemaining.toLocaleString()}
              </td>
              <td className="px-4 py-4" colSpan={2}></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  )
}
