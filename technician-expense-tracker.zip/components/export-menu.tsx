"use client"

import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Download, FileText, FileSpreadsheet, Printer } from "lucide-react"
import type { Technician } from "@/lib/types"
import { generatePDF } from "@/lib/pdf-generator"
import { generateExcel } from "@/lib/excel-generator"
import { useToast } from "@/hooks/use-toast"

interface ExportMenuProps {
  technicians: Technician[]
  miscExpenses: { label: string; amount: number }[]
  totalRemaining: number
  finalRemaining: number
}

export function ExportMenu({ technicians, miscExpenses, totalRemaining, finalRemaining }: ExportMenuProps) {
  const { toast } = useToast()

  const handlePDFExport = () => {
    try {
      generatePDF(technicians, miscExpenses, totalRemaining, finalRemaining)
      toast({
        title: "PDF exported successfully",
        description: "Your expense report has been downloaded.",
      })
    } catch (error) {
      toast({
        title: "Export failed",
        description: "There was an error generating the PDF.",
        variant: "destructive",
      })
    }
  }

  const handleExcelExport = () => {
    try {
      generateExcel(technicians, miscExpenses, totalRemaining, finalRemaining)
      toast({
        title: "Excel exported successfully",
        description: "Your expense report has been downloaded.",
      })
    } catch (error) {
      toast({
        title: "Export failed",
        description: "There was an error generating the Excel file.",
        variant: "destructive",
      })
    }
  }

  const handlePrint = () => {
    window.print()
    toast({
      title: "Print dialog opened",
      description: "Your expense report is ready to print.",
    })
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button className="bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white shadow-lg">
          <Download className="mr-2 h-4 w-4" />
          Export
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuItem onClick={handlePDFExport} className="cursor-pointer">
          <FileText className="mr-2 h-4 w-4" />
          Export as PDF
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handleExcelExport} className="cursor-pointer">
          <FileSpreadsheet className="mr-2 h-4 w-4" />
          Export as Excel
        </DropdownMenuItem>
        <DropdownMenuItem onClick={handlePrint} className="cursor-pointer">
          <Printer className="mr-2 h-4 w-4" />
          Print
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
