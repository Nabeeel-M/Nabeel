"use client"

import { Card } from "@/components/ui/card"
import type { Technician, Transaction } from "@/lib/types"
import { DollarSign, TrendingUp, TrendingDown, Users } from "lucide-react"

interface DashboardStatsProps {
  technicians: Technician[]
  transactions: Transaction[]
}

export function DashboardStats({ technicians, transactions }: DashboardStatsProps) {
  const totalReceived = technicians.reduce((sum, tech) => sum + tech.totalReceived, 0)
  const totalExpenses = technicians.reduce((sum, tech) => sum + tech.totalExpense, 0)
  const totalRemaining = technicians.reduce((sum, tech) => sum + tech.remaining, 0)
  const activeTechnicians = technicians.filter((t) => t.status === "active").length

  const recentTransactions = transactions.slice(-10)
  const recentReceived = recentTransactions.filter((t) => t.type === "received").reduce((sum, t) => sum + t.amount, 0)
  const recentExpenses = recentTransactions.filter((t) => t.type === "expense").reduce((sum, t) => sum + t.amount, 0)

  const stats = [
    {
      title: "Total Received",
      value: totalReceived.toLocaleString(),
      icon: TrendingUp,
      color: "text-primary",
      bgColor: "bg-primary/10",
      trend: recentReceived > 0 ? `+${recentReceived.toLocaleString()} recent` : null,
    },
    {
      title: "Total Expenses",
      value: totalExpenses.toLocaleString(),
      icon: TrendingDown,
      color: "text-destructive",
      bgColor: "bg-destructive/10",
      trend: recentExpenses > 0 ? `${recentExpenses.toLocaleString()} recent` : null,
    },
    {
      title: "Total Remaining",
      value: totalRemaining.toLocaleString(),
      icon: DollarSign,
      color: "text-chart-2",
      bgColor: "bg-chart-2/10",
      trend: totalRemaining > 0 ? "Positive balance" : "Needs attention",
    },
    {
      title: "Active Technicians",
      value: activeTechnicians.toString(),
      icon: Users,
      color: "text-foreground",
      bgColor: "bg-muted",
      trend: `${technicians.length} total`,
    },
  ]

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => {
        const Icon = stat.icon
        return (
          <Card key={stat.title} className="p-6 transition-shadow hover:shadow-lg">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
                <p className="mt-2 text-3xl font-bold tracking-tight">{stat.value}</p>
                {stat.trend && <p className="mt-1 text-xs text-muted-foreground">{stat.trend}</p>}
              </div>
              <div className={`rounded-xl p-3 ${stat.bgColor}`}>
                <Icon className={`h-6 w-6 ${stat.color}`} />
              </div>
            </div>
          </Card>
        )
      })}
    </div>
  )
}
