"use client"

import { Card } from "@/components/ui/card"
import type { Transaction } from "@/lib/types"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts"

interface ExpenseChartProps {
  transactions: Transaction[]
}

export function ExpenseChart({ transactions }: ExpenseChartProps) {
  // Group transactions by category
  const categoryData = transactions.reduce(
    (acc, transaction) => {
      const category = transaction.category
      if (!acc[category]) {
        acc[category] = { category, received: 0, expense: 0 }
      }
      if (transaction.type === "received") {
        acc[category].received += transaction.amount
      } else {
        acc[category].expense += transaction.amount
      }
      return acc
    },
    {} as Record<string, { category: string; received: number; expense: number }>,
  )

  const chartData = Object.values(categoryData)

  return (
    <Card className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold">Category Breakdown</h2>
        <p className="text-sm text-muted-foreground">Financial overview by transaction category</p>
      </div>
      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <XAxis dataKey="category" className="text-xs" />
            <YAxis className="text-xs" />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
              }}
            />
            <Legend />
            <Bar dataKey="received" fill="hsl(var(--primary))" name="Received" radius={[8, 8, 0, 0]} />
            <Bar dataKey="expense" fill="hsl(var(--destructive))" name="Expense" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </Card>
  )
}
