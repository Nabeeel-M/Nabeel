"use client"

import { Card } from "@/components/ui/card"
import type { Technician } from "@/lib/types"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"

interface TopTechniciansProps {
  technicians: Technician[]
}

export function TopTechnicians({ technicians }: TopTechniciansProps) {
  const sortedTechnicians = [...technicians]
    .filter((t) => t.totalReceived > 0)
    .sort((a, b) => b.totalReceived - a.totalReceived)
    .slice(0, 5)

  const maxReceived = Math.max(...sortedTechnicians.map((t) => t.totalReceived), 1)

  return (
    <Card className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold">Top Technicians</h2>
        <p className="text-sm text-muted-foreground">Highest total received amounts</p>
      </div>
      <div className="space-y-4">
        {sortedTechnicians.length === 0 ? (
          <p className="text-center text-sm text-muted-foreground">No data available</p>
        ) : (
          sortedTechnicians.map((technician, index) => {
            const percentage = (technician.totalReceived / maxReceived) * 100
            const initials = technician.name
              .split(" ")
              .map((n) => n[0])
              .join("")
              .toUpperCase()
              .slice(0, 2)

            return (
              <div key={technician.id} className="space-y-2">
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">
                    {index + 1}
                  </div>
                  <Avatar className="h-10 w-10">
                    <AvatarFallback className="bg-accent text-accent-foreground">{initials}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <p className="font-medium">{technician.name}</p>
                    <p className="text-sm text-muted-foreground">{technician.totalReceived.toLocaleString()}</p>
                  </div>
                </div>
                <Progress value={percentage} className="h-2" />
              </div>
            )
          })
        )}
      </div>
    </Card>
  )
}
