"use client"

import { Card } from "@/components/ui/card"
import { TrendingUp, TrendingDown, Users, DollarSign } from "lucide-react"
import type { Technician } from "@/lib/types"

interface StatsCardsProps {
  technicians: Technician[]
  totalRemaining: number
  finalRemaining: number
}

export function StatsCards({ technicians, totalRemaining, finalRemaining }: StatsCardsProps) {
  const totalReceived = technicians.reduce((sum, tech) => sum + tech.totalReceived, 0)
  const totalExpense = technicians.reduce((sum, tech) => sum + tech.totalExpense, 0)
  const activeTechnicians = technicians.filter((tech) => tech.name.trim() !== "").length

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      <Card className="p-4 bg-gradient-to-br from-teal-50 to-emerald-50 border-teal-200">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-600">Total Received</p>
            <p className="text-2xl font-bold text-teal-700">{totalReceived.toLocaleString()}</p>
          </div>
          <div className="h-12 w-12 rounded-full bg-teal-100 flex items-center justify-center">
            <TrendingUp className="h-6 w-6 text-teal-600" />
          </div>
        </div>
      </Card>

      <Card className="p-4 bg-gradient-to-br from-red-50 to-orange-50 border-red-200">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-600">Total Expense</p>
            <p className="text-2xl font-bold text-red-700">{totalExpense.toLocaleString()}</p>
          </div>
          <div className="h-12 w-12 rounded-full bg-red-100 flex items-center justify-center">
            <TrendingDown className="h-6 w-6 text-red-600" />
          </div>
        </div>
      </Card>

      <Card className="p-4 bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-600">Active Technicians</p>
            <p className="text-2xl font-bold text-blue-700">{activeTechnicians}</p>
          </div>
          <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center">
            <Users className="h-6 w-6 text-blue-600" />
          </div>
        </div>
      </Card>

      <Card className="p-4 bg-gradient-to-br from-emerald-50 to-teal-50 border-emerald-200">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-slate-600">Final Balance</p>
            <p className="text-2xl font-bold text-emerald-700">{finalRemaining.toLocaleString()}</p>
          </div>
          <div className="h-12 w-12 rounded-full bg-emerald-100 flex items-center justify-center">
            <DollarSign className="h-6 w-6 text-emerald-600" />
          </div>
        </div>
      </Card>
    </div>
  )
}
