"use client"

import { useState, useMemo } from "react"
import type { Technician } from "@/lib/types"
import { initialTechnicians } from "@/lib/data"
import { SpreadsheetTable } from "@/components/spreadsheet-table"
import { Button } from "@/components/ui/button"
import { Trash2, Plus, Calculator, Save, Upload } from "lucide-react"
import { ExportMenu } from "@/components/export-menu"
import { SearchFilter } from "@/components/search-filter"
import { StatsCards } from "@/components/stats-cards"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { useToast } from "@/hooks/use-toast" // Import useToast hook

export default function Home() {
  const [technicians, setTechnicians] = useState<Technician[]>(initialTechnicians)
  const [miscExpenses, setMiscExpenses] = useState([
    { label: "hanzla", amount: 5000 },
    { label: "Return", amount: -4000 },
    { label: "Tea", amount: -180 },
  ])
  const [searchTerm, setSearchTerm] = useState("")
  const { toast } = useToast() // Declare useToast hook

  const filteredTechnicians = useMemo(() => {
    if (!searchTerm.trim()) return technicians
    return technicians.filter((tech) => tech.name.toLowerCase().includes(searchTerm.toLowerCase()))
  }, [technicians, searchTerm])

  const totalRemaining = technicians.reduce((sum, tech) => sum + tech.remaining, 0)
  const miscTotal = miscExpenses.reduce((sum, exp) => sum + exp.amount, 0)
  const finalRemaining = totalRemaining + miscTotal

  const handleClearAll = () => {
    setTechnicians(
      technicians.map((tech) => ({
        ...tech,
        totalReceived: 0,
        totalExpense: 0,
        remaining: 0,
      })),
    )
    toast({
      title: "All entries cleared",
      description: "All financial data has been reset to zero.",
    })
  }

  const handleAddTechnician = () => {
    const newTechnician: Technician = {
      id: Date.now().toString(),
      name: "",
      totalReceived: 0,
      totalExpense: 0,
      remaining: 0,
      status: "active",
      createdAt: new Date(),
    }
    setTechnicians([...technicians, newTechnician])
  }

  const handleBackupData = () => {
    const data = {
      technicians,
      miscExpenses,
      exportDate: new Date().toISOString(),
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `expense-backup-${new Date().toISOString().split("T")[0]}.json`
    a.click()
    URL.revokeObjectURL(url)
    toast({
      title: "Backup created",
      description: "Your data has been backed up successfully.",
    })
  }

  const handleRestoreData = () => {
    const input = document.createElement("input")
    input.type = "file"
    input.accept = ".json"
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0]
      if (file) {
        const reader = new FileReader()
        reader.onload = (event) => {
          try {
            const data = JSON.parse(event.target?.result as string)
            setTechnicians(data.technicians)
            setMiscExpenses(data.miscExpenses)
            toast({
              title: "Data restored",
              description: "Your backup has been restored successfully.",
            })
          } catch (error) {
            toast({
              title: "Restore failed",
              description: "Invalid backup file format.",
              variant: "destructive",
            })
          }
        }
        reader.readAsText(file)
      }
    }
    input.click()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-emerald-50 to-cyan-50 p-4 sm:p-8">
      <div className="mx-auto max-w-7xl space-y-6">
        <div className="rounded-2xl bg-white/80 backdrop-blur-sm p-6 sm:p-8 shadow-xl border border-teal-100">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-teal-600 to-emerald-600 shadow-lg">
                <Calculator className="h-8 w-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-to-r from-teal-700 to-emerald-700 bg-clip-text text-transparent">
                  Expense Tracker
                </h1>
                <p className="mt-1 text-sm sm:text-base text-slate-600">Manage finances and track balances</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-3 w-full sm:w-auto">
              <ExportMenu
                technicians={technicians}
                miscExpenses={miscExpenses}
                totalRemaining={totalRemaining}
                finalRemaining={finalRemaining}
              />
              <Button
                onClick={handleBackupData}
                variant="outline"
                className="border-teal-300 hover:bg-teal-50 text-teal-700 bg-transparent"
              >
                <Save className="mr-2 h-4 w-4" />
                Backup
              </Button>
              <Button
                onClick={handleRestoreData}
                variant="outline"
                className="border-teal-300 hover:bg-teal-50 text-teal-700 bg-transparent"
              >
                <Upload className="mr-2 h-4 w-4" />
                Restore
              </Button>
              <Button
                onClick={handleAddTechnician}
                className="bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white shadow-lg"
              >
                <Plus className="mr-2 h-4 w-4" />
                Add Row
              </Button>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" className="shadow-lg">
                    <Trash2 className="mr-2 h-4 w-4" />
                    Clear All
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Clear all entries?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will reset all financial data to zero. This action cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleClearAll} className="bg-red-600 hover:bg-red-700">
                      Clear All
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </div>
        </div>

        <StatsCards technicians={technicians} totalRemaining={totalRemaining} finalRemaining={finalRemaining} />

        <div className="rounded-2xl bg-white/80 backdrop-blur-sm p-4 shadow-xl border border-teal-100">
          <SearchFilter searchTerm={searchTerm} onSearchChange={setSearchTerm} />
        </div>

        <SpreadsheetTable
          technicians={filteredTechnicians}
          setTechnicians={setTechnicians}
          miscExpenses={miscExpenses}
          setMiscExpenses={setMiscExpenses}
          totalRemaining={totalRemaining}
          finalRemaining={finalRemaining}
        />
      </div>
    </div>
  )
}
